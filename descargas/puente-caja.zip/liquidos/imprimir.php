<?php
/* =========================================================
   LIQUIDOS MARKET - Puente de impresión (Proyecto Caja)
   Va en: C:\xampp\htdocs\liquidos\imprimir.php
   Recibe la venta desde la app, imprime el recibo en la
   impresora térmica y abre el cajón (solo efectivo).
   ========================================================= */

// ---- AJUSTES ------------------------------------------------
$IMPRESORA = 'POS';      // nombre con el que se compartió la impresora en Windows
$ACENTOS   = true;       // si las tildes salen raras en el papel, cambiar a false
$ORIGENES  = ['https://liquidosmarket161016-pixel.github.io', 'http://localhost', 'http://127.0.0.1'];
// -------------------------------------------------------------

const VERSION = '1.2';
$NEG = ['nombre' => 'LIQUIDOS MARKET', 'id' => 'NIT/CC 1143960671', 'dir' => 'CALLE 60 No. 98D - 36',
        'cel' => 'Cel. 3206364169', 'email' => 'liquidosmarket161016@gmail.com'];
$LOGO = base64_decode('HXYwADIAlAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/////////////////////////////////////////////////////////8AAAAAAAD///////////////////////////////////////////////////////////AAAAAAA////////////////////////////////////////////////////////////gAAAAAP////////////////////////////////////////////////////////////AAAAAD/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH/AAAAAfwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD+AAAAD8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8AAAAfgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH4AAAB8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPgAAAPgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfAAAB8AAAAAAAAAAAAH8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA+AAAHgAAAAAAAAAAAA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAA+AAAAAAAAAAAAH+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHwAADwAAAAAAAAAAAA/4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPAAAPAAAAAAAAAAAAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAB4AAAAAAAAAAAAf4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAHgAAAAAAAAAAAD/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAeAAAAAAAAAAAAf4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAB4AAAAAAAAAAAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAHgAAAAAAAAAAAP8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAeAAAAAAAAAAAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAB4AAAAAAAAAAAH8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAHgAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAB4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAB4AAAAAAAAAAAH4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH+AAAB4AAHgAAAAAAAAAAAfwAAAAAP/4AAAAAAAAAAAAAAAAAAAAAAAAAAAf+AAAAAH//gAAHgAAeAAAAAAAAAAAD/AAAAAH//8AAAD/8AAAD/4H/4H///wAAAAAAP//gAAAB///gAAeAAB4AAP/wAAAAAAP8AAAAD///+AAAP/wAAAP/gf/gf///4AAAAAH///gAAAf///gAB4AAHgAA//AAAAAAAfwAAAA////+AAA//AAAA/+B/+B////8AAAAB////gAAD////AAHgAAeAAD/8AAAAAAD/AAAAP////8AAD/8AAAD/4H/4H////8AAAAP////gAAf////AAeAAB4AAP/wAAAAAAP8AAAB/////8AAP/wAAAP/gf/gf////8AAAD/////AAD////+AB4AAHgAA//AAAAAAA/wAAAP/////4AA//AAAA/+B/+B/////4AAAf/////AAf////4AHgAAeAAD/8AAAAAAD/AAAD//////wAD/8AAAD/4H/4H/////wAAD/////+AB/////AAeAAB4AAP/wAAAAAAP8AAAf//////gAP/wAAAP/gf/gf/////gAAf/////8AP////4AB4AAHgAA//AAAAAAAfwAAD///////AA//AAAA/+B/+B//////AAD//////4A/////AAHgAAeAAD/8AAAAAAD/AAAf//////+AD/8AAAD/4H/4H/////+AAf//////wH//j/4AAeAAB4AAP/wAAAAAAP8AAB///////8AP/wAAAP/gf/gf/////8AB///////Af/4A/AAB4AAHgAA//AAAAAAA/4AAP//4AP//4A//AAAA/+B/+B/+Af//4AP//wB//+B//AB4AAHgAAeAAD/8AAAAAAH/wAB//8AAP//wD/8AAAD/4H/4H/4AP//gB//8AB//8H/8ABgAAeAAB4AAP/wAAAAAA//gAH//gAAP//AP/wAAAP/gf/gf/gAP//AH//AAB//wf/wAAAAB4AAHgAA//AAAAAAH//AA//4AAAf/+A//AAAA/+B/+B/+AAf/8A//4AAD//h//AAAAAHgAAeAAD/8AAAAAA//+AD//AAAAf/4D/8AAAD/4H/4H/4AA//4D//AAAH/+H/8AAAAAeAAB4AAP/wAAAAAHn/8Af/4AAAA//wP/wAAAP/gf/gf/gAB//gf/4AAAP/8f/8AAAAB4AAHgAA//AAAAAA8//wB//gAAAD//A//AAAA/+B/+B/+AAD/+B//AAAAf/x//8AAAAHgAAeAAD/8AAAAADj//AP/8AAAAH/8D/8AAAD/4H/4H/4AAH/8H/8AAAB//D//8AAAAeAAB4AAP/wAAAAAOf/+A//gAAAAP/4P/wAAAP/gf/gf/gAAf/w//gAAAD/+P//+AAAB4AAHgAA//AAAAAA5//4D/+AAAAA//g//AAAA/+B/+B/+AAA//D/+AAAAP/4f//+AAAHgAAeAAD/8AAAAADn//gf/wAAAAB/+D/8AAAD/4H/4H/4AAD/8P/wAAAAf/h///+AAAeAAB4AAP/wAAAAAOf/+B//AAAAAH/4P/wAAAP/gf/gf/gAAP/4//AAAAB/+D///+AAB4AAHgAA//AAAAAA5//4H/8AAAAAf/w//AAAA/+B/+B/+AAA//j/8AAAAH/4H///8AAHgAAeAAD/8AAAAADn//gf/gAAAAB//D/8AAAD/4H/4H/4AAB/+P/wAAAAf/gP///8AAeAAB4AAP/wAAAAAOf/+B/+AAAAAD/8P/wAAAP/gf/gf/gAAH/5//AAAAB/+AP///4AB4AAHgAA//AAAAAA5//4H/4AAAAAP/w//AAAA/+B/+B/+AAAf/n/8AAAAH/4Af///wAHgAAeAAD/8AAAAADn//gf/gAAAAA//D/8AAAD/4H/4H/4AAB/+f/wAAAAf/gAf///AAeAAB4AAP/wAAAAAOf/+B/+AAAAAH/8P/wAAAP/gf/gf/gAAP/4//AAAAB/+AAf//+AB4AAHgAA//AAAAAA5//4H/8AAAAAf/w//AAAA/+B/+B/+AAA//D/8AAAAH/4AAP//4AHgAAeAAD/8AAAAADn//gf/wAABgB/+D/8AAAD/4H/4H/4AAD/8P/wAAAAf/gAAP//wAeAAB4AAP/wAAAAAOf/+B//AAAPAH/4P/wAAAf/gf/gf/gAAP/w//gAAAD/+AAAP//AB4AAHgAA//AAAAAA5/54D/8AAB+A//g//gAAB/+B/+B/+AAB//D/+AAAAP/4AAAP/8AHgAAeAAD/8AAAAADj8HgP/4AAP8D/+D/+AAAH/4H/4H/4AAH/8H/8AAAB//AAAAf/wAeAAB4AAP/wAAAAAOAAeA//gAB/4f/4H/4AAAf/gf/gf/gAA//gf/wAAAH/8AAAA//gB4AAHgAA//AAAAAA4AB4D//AAP/x//Af/wAAD/+B/+B/+AAH/+B//gAAA//wAAAD/+AHgAAeAAD/8AAAAADgAHgH/+AB////8B//AAAP/4H/4H/4AA//4D//AAAH/+AIAAP/4AeAAB4AAP/wAAAAAOAAeAf/8AD////gH/+AAB//Af/gf/gAH//AP/+AAA//4BwAA//AB4AAHgAA//AAAAAA4AB4A//4AH///+AP/8AAP/8B/+B/+AA//4Af/8AAH//APgAH/8AHgAAeAAD//////wDgAHgD//wAP///wA//4AB//wH/4H/4AP//gB//8AB//8B/AAf/wAeAAB4AAP//////AOAAeAH//wAf///AB//4Af/+Af/gf/gP//8AD//8Af//gP/AD//AB4AAHgAA//////8A4AB4Af//wA///4AH//+f//4B/+B//////wAP//////8B//x//8AHgAAeAAD//////wDgAHgA///4D///gAP//////AH/4H/////+AAf//////wP/////gAeAAB4AAP//////AOAAeAB///////8AA//////4Af/gf/////wAA//////+B/////+AB4AAHgAA//////8A4AB4AD///////gAB//////gB/+B/////+AAB//////wH/////wAHgAAeAAD//////wDgAHgAH//////+AAD/////8AH/4H/////wAAD/////+Af/////AAeAAB4AAP//////AOAAeAAP//////8AAH/////gAf/gf////8AAAH/////wA/////4AB4AAHgAA//////8A4AB4AAf//////4AAP////8AB/+B/////gAAAP////8AB/////AAHgAAeAAD//////wDgAfgAA///////4AAf////gAH/4H////4AAAAP////gAB////4AAeAAB4AAP//////AOf/+AAA///////wAA////8AAf/gf///+AAAAAf///4AAD///+AAB4AAHgAA//////8A5//4AAB///////gAA////AAB/+B////gAAAAAf//+AAAD///wAAHgAAeAAAAAAAAAADn//gAAB////n//AAA///wAAH/4H///gAAAAAAP//gAAAB//4AAAeAAB4AAAAAAAAAAOf/+AAAB///4P/8AAAf/4AAAAAAAAAAAAAAAAAH/gAAAAA/8AAAB4AAHgAAAAAAAAAA5//4AAAAf/8Af/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAeAAAAAAAAAADn//gAAAAAAAA/8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAB4AAAAAAAAAAOf/+AAAAAAAAB/gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAHgAAAAAAAAAA5//4AAAAAAAAD8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAeAAAAAAAAAADn//gAAAAAAAAHgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAB4AAAAAAAAAAOf/+AAAAAAAAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAHgAAAAAAAAAA5//4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAeAAAAAAAAAADn//gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeAAB4AAAAAAAAAAOf/+AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB4AAHgAAAAAAAAAA///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHgAAPAAAAAAAAAAB///AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8AAA8AAAAAAAAAAB//gAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADwAAD4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAfAAAHgAAAAAAAAAAAAAAAAADgDgAABgAAB/AAAGA4AAf+AAP/gAAAAAAAAAAAAAAAAB4AAAfAAAAAAAAAAAAAAAAAAeAeAAAPAAAH/AAA4PAAD/4AA/+AAAAAAAAAAAAAAAAAPgAAA+AAAAAAAAAAAAAAAAAB8B4AAA8AAAf+AADg4AAP/gAD/4AAAAAAAAAAAAAAAAB8AAAB8AAAAAAAAAAAAAAAAAH4PgAAHwAABg4AAOHAAA4AAAA4AAAAAAAAAAAAAAAAAPgAAAD4AAAAAAAAAAAAAAAAAfh+AAAfgAAHBwAA44AABgAAADgAAAAAAAAAAAAAAAAB8AAAAP4AAAAAAAAAAAAAAAAB/H4AADuAAAYHAADnAAAGAAAAOAAAAAAAAAAAAAAAAAfgAAAAf4AAAAAAAAAAAAAAAAHc7gAAOcAABg4AAP4AAA94AAA4AAAAAAAAAAAAAAAAH8AAAAAf+AAAAAAAAAAAAAAAAc7uAAA5wAAHfgAA/gAAD/wAADgAAAAAAAAAAAAAAAD/gAAAAA///////////////wABz84AAHDgAAf8AAD/AAAP/AAAOAAD//////////////8AAAAAA///////////////AAHHzgAAcOAAB/gAAPeAAAcAAAA4AAP//////////////AAAAAAA//////////////8AAceOAAD/4AAHPAAA84AADgAAADgAA//////////////wAAAAAAAAAAAAAAAAAAAAAAABw44AAP/wAAYcAADhwAAOAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHADgAB4HAABw4AAOHgAAYAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcAOAAHAeAAGDgAA4PAAD/4AADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwA4AAcA4AAcHAADgeAAP/gAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADADgADgDgABgcAAGA4AAf+AAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAH4AwAOAAwAAD4AAAAAAAAAAAYAOAAABgAAAAAAAYAAAHAAAAAAAAAAAAAAAAAAAAAAAfgPwD+APwAAfgMIAAYYDCAAHwB8AQAfgAAwAggH4AwA/AAAAAAAAAAAAAAAAAAAAAAAYAhgMMBhgABgA4gABhgMIAAQAIIBADDAADACCAwADgCGAAAAAAAAAAAAAAAAAAAAAABgGDAwQECAAGADiAAGGA4gABgBgwEAIEAAMAIICAAaAIYAAAAAAAAAAAAAAAAAAAAAAGAQMDBAQMAAfALIAAYYCyAADgEBAQBgQAAwAggYABsAhAAAAAAAAAAAAAAAAAAAAAAAYBAwMGBAwAB8AmgABhgJIAADAQEBAGBAADACCBhgEQD8AAAAAAAAAAAAAAAAAAAAAABgGDAwQECAAEACOAAGGAjgAAGBgwEAIEAAMAIICCA/gNgAAAAAAAAAAAAAAAAAAAAAAGAIYDDAYYAAQAIYAAIQCOAAEYCCAQAwwAAwAxgMIDCAjAAAAAAAAAAAAAAAAAAAAAAAYA/AP4A/AAB+AhgAA/AIYAAfAHwB8B+AAD4B8AfgYMCEAAAAAAAAAAAAAAAAAAAAAAAAAwAEAAwAAD4AAAAAwAAAAAYAOADgBgAAFgDAAYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA==');

$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($origin, $ORIGENES, true) || strpos($origin, 'claudeusercontent') !== false) {
  header('Access-Control-Allow-Origin: ' . $origin);
  header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Private-Network: true');
header('Content-Type: application/json; charset=utf-8');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

function responder($a) { echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; }

// ---- ESC/POS ------------------------------------------------
const ESC = "\x1b"; const GS = "\x1d";
function txt($s) {
  global $ACENTOS;
  if ($ACENTOS) { $r = @iconv('UTF-8', 'CP850//TRANSLIT', $s); if ($r !== false) return $r; }
  $s = strtr($s, ['á'=>'a','é'=>'e','í'=>'i','ó'=>'o','ú'=>'u','Á'=>'A','É'=>'E','Í'=>'I','Ó'=>'O','Ú'=>'U','ñ'=>'n','Ñ'=>'N','ü'=>'u','¡'=>'!','¿'=>'?']);
  return preg_replace('/[^\x20-\x7E\n]/', '', $s);
}
function plata($n) { return '$' . number_format((float)$n, 0, ',', '.'); }
function fila($izq, $der, $ancho = 48) {
  $izq = mb_substr($izq, 0, max(1, $ancho - mb_strlen($der) - 1));
  return $izq . str_repeat(' ', max(1, $ancho - mb_strlen($izq) - mb_strlen($der))) . $der . "\n";
}
function centro()   { return ESC . "a\x01"; }
function izquierda(){ return ESC . "a\x00"; }
function negrilla($on) { return ESC . 'E' . ($on ? "\x01" : "\x00"); }
function grande($on)   { return GS . '!' . ($on ? "\x11" : "\x00"); }
function cajon()   { return ESC . "p\x00\x19\xfa"; }   // pulso al cajón (pin 2)
function cortar()  { return "\n\n\n" . GS . "V\x42\x00"; }

function recibo($v) {
  global $NEG, $LOGO;
  $o = ESC . '@' . ESC . "t\x02";                     // reiniciar + tabla de caracteres CP850
  $o .= centro() . $LOGO . "\n";
  $o .= negrilla(true) . txt($NEG['nombre']) . "\n" . negrilla(false);
  $o .= txt($NEG['id'] . "\n" . $NEG['dir'] . "\n" . $NEG['cel'] . "\n");
  $o .= str_repeat('-', 48) . "\n";
  $o .= negrilla(true) . txt("COMPROBANTE DE VENTA\n") . negrilla(false) . txt("NO ES FACTURA\n");
  $o .= izquierda();
  if (!empty($v['num']))   $o .= txt(fila('Venta No.', (string)$v['num']));
  $o .= txt(fila('Fecha', $v['fecha'] ?? date('d/m/Y h:i a')));
  if (!empty($v['cuenta'])) $o .= txt(fila('Cuenta', $v['cuenta']));
  if (!empty($v['cobro']))  $o .= txt(fila('Atendió', $v['cobro']));
  $o .= str_repeat('-', 48) . "\n";
  foreach (($v['items'] ?? []) as $it) {
    $q = $it['q'] ?? 1; $p = $it['p'] ?? 0;
    $o .= txt(mb_substr($it['n'] ?? '', 0, 48) . "\n");
    $o .= txt(fila('  ' . $q . ' x ' . plata($p), plata($q * $p)));
  }
  $o .= str_repeat('-', 48) . "\n";
  $o .= negrilla(true) . grande(true) . txt(fila('TOTAL', plata($v['total'] ?? 0), 24)) . grande(false) . negrilla(false) . "\n";
  if (!empty($v['efectivo']))      $o .= txt(fila('Efectivo recibido', plata($v['efectivo'])));
  if (!empty($v['cambio']))        $o .= txt(fila('Cambio', plata($v['cambio'])));
  if (!empty($v['transferencia'])) $o .= txt(fila('Transferencia', plata($v['transferencia'])));
  $o .= "\n" . centro() . txt("¡Gracias por su compra!\n" . $NEG['email'] . "\n");
  return $o;
}


function parrafo($s, $ancho = 48) {
  $o = '';
  foreach (preg_split("/\r?\n/", (string)$s) as $linea) $o .= wordwrap(txt($linea), $ancho, "\n", true) . "\n";
  return $o;
}
function cierreTicket($c) {
  global $NEG, $LOGO;
  $L = str_repeat('-', 48) . "\n";
  $o = ESC . '@' . ESC . "t\x02" . centro() . $LOGO . "\n";
  $o .= negrilla(true) . txt($NEG['nombre']) . "\n" . grande(true) . txt("CIERRE DE CAJA\n") . grande(false) . negrilla(false);
  $o .= txt(($c['dia'] ?? '') . "\n") . izquierda() . $L;
  $o .= txt(fila('Abrió', trim(($c['abrio'] ?? '') . ' ' . ($c['hora_abrio'] ?? ''))));
  $o .= txt(fila('Cerró', trim(($c['cerro'] ?? '') . ' ' . ($c['hora_cerro'] ?? ''))));
  $o .= $L . negrilla(true) . txt("VENTAS DEL DÍA\n") . negrilla(false);
  $o .= txt(fila('Número de ventas', (string)($c['ventas'] ?? 0)));
  $o .= txt(fila('Total vendido', plata($c['total'] ?? 0)));
  $o .= txt(fila('  Efectivo', plata($c['efectivo'] ?? 0)));
  $o .= txt(fila('  Transferencias', plata($c['transferencias'] ?? 0)));
  $o .= $L . negrilla(true) . txt("GASTOS DE CAJA\n") . negrilla(false);
  if (empty($c['gastos'])) $o .= txt("Sin gastos\n");
  else { foreach ($c['gastos'] as $g) $o .= txt(fila('  ' . ($g['c'] ?? ''), plata($g['v'] ?? 0))); $o .= txt(fila('Total gastos', plata($c['total_gastos'] ?? 0))); }
  $o .= $L . negrilla(true) . txt("CUADRE DE CAJA\n") . negrilla(false);
  $o .= txt(fila('Base inicial', plata($c['base'] ?? 0)));
  $o .= txt(fila('+ Efectivo vendido', plata($c['efectivo'] ?? 0)));
  $o .= txt(fila('- Gastos', plata($c['total_gastos'] ?? 0)));
  $o .= txt(fila('Debía haber', plata($c['esperado'] ?? 0)));
  $o .= txt(fila('Había en caja', plata($c['contado'] ?? 0)));
  $d = (int)($c['diferencia'] ?? 0);
  $o .= negrilla(true) . txt(fila('Resultado', $d === 0 ? 'CUADRÓ' : ($d > 0 ? 'SOBRAN ' . plata($d) : 'FALTAN ' . plata(-$d)))) . negrilla(false);
  $o .= $L;
  $o .= txt(fila('Base para mañana', plata($c['base_manana'] ?? 0)));
  $o .= negrilla(true) . grande(true) . txt(fila('SE LLEVA', plata($c['se_lleva'] ?? 0), 24)) . grande(false) . negrilla(false) . "\n";
  if (!empty($c['abiertas'])) $o .= txt(fila('Cuentas sin cobrar: ' . $c['abiertas'], plata($c['total_abiertas'] ?? 0)));
  if (trim($c['notas'] ?? '') !== '') { $o .= $L . negrilla(true) . txt("NOTAS PARA EL SIGUIENTE TURNO\n") . negrilla(false) . parrafo($c['notas']); }
  $o .= $L . "\n" . txt("Firma: ______________________________\n");
  return $o;
}

function enviar($datos) {
  global $IMPRESORA;
  $equipo = getenv('COMPUTERNAME') ?: gethostname();
  $rutas = ['\\\\localhost\\' . $IMPRESORA, '\\\\' . $equipo . '\\' . $IMPRESORA];
  foreach ($rutas as $ruta) {
    $f = @fopen($ruta, 'wb');
    if ($f) { fwrite($f, $datos); fclose($f); return [true, $ruta]; }
  }
  // plan B: copiar el archivo a la impresora compartida con el comando de Windows
  $tmp = tempnam(sys_get_temp_dir(), 'lm');
  file_put_contents($tmp, $datos);
  foreach ($rutas as $ruta) {
    exec('copy /b "' . $tmp . '" "' . $ruta . '" 2>&1', $out, $code);
    if ($code === 0) { @unlink($tmp); return [true, $ruta . ' (copy)']; }
  }
  @unlink($tmp);
  return [false, 'No se encontró la impresora compartida "' . $IMPRESORA . '". Revisa que esté compartida con ese nombre.'];
}

// ---- RUTAS --------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  responder(['ok' => true, 'puente' => 'Liquidos Market', 'version' => VERSION, 'impresora' => $IMPRESORA, 'equipo' => getenv('COMPUTERNAME') ?: gethostname()]);
}
$in = json_decode(file_get_contents('php://input'), true);
if (!is_array($in)) responder(['ok' => false, 'error' => 'Datos inválidos']);
$accion = $in['accion'] ?? 'recibo';

if ($accion === 'cajon') { $datos = ESC . '@' . cajon(); }
elseif ($accion === 'cierre') { $datos = cierreTicket($in['cierre'] ?? []) . cortar(); }
else {
  $v = $in['venta'] ?? [];
  $datos = recibo($v);
  // el cajón se abre solo si hubo efectivo (efectivo o mixto)
  if (($in['cajon'] ?? true) !== false && (!empty($v['efectivo']) || ($v['metodo'] ?? '') === 'efectivo' || ($v['metodo'] ?? '') === 'mixto')) $datos .= cajon();
  $datos .= cortar();
}
[$ok, $det] = enviar($datos);
responder(['ok' => $ok, 'detalle' => $det, 'bytes' => strlen($datos)]);
